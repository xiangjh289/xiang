class SpeechRecognition {
    constructor() {
        this.audioData = '';
    }

    getInfo() {
        return {
            id: 'speechRecognition',
            name: 'Speech Recognition',
            blocks: [
                {
                    opcode: 'recognizeSpeech',
                    blockType: Scratch.BlockType.REPORTER,
                    text: 'recognize speech [AUDIO]',
                    arguments: {
                        AUDIO: {
                            type: Scratch.ArgumentType.STRING,
                            defaultValue: 'audioData'
                        }
                    }
                }
            ]
        };
    }

    recognizeSpeech(args) {
        return new Promise((resolve, reject) => {
            fetch('http://localhost:3000/recognize', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({ audioData: args.AUDIO })
            })
            .then(response => response.json())
            .then(data => {
                resolve(data.result);
            })
            .catch(error => {
                console.error('Error:', error);
                reject('Failed to recognize speech');
            });
        });
    }
}

Scratch.extensions.register(new SpeechRecognition());
