const express = require('express');
const axios = require('axios');
const bodyParser = require('body-parser');

const app = express();
const port = 3000;

const API_KEY = 'c6f349c49d6d38a74aa5e224f3e53f14'; // 替换为你的科大讯飞API Key
const APP_ID = '584e2fbb';   // 替换为你的科大讯飞APP ID

app.use(bodyParser.json());

app.post('/recognize', async (req, res) => {
    const { audioData } = req.body;

    try {
        const response = await axios.post('https://api.xfyun.cn/v1/service/v1/iat', {
            audioData: audioData,
            appid: APP_ID,
            apikey: API_KEY
        }, {
            headers: {
                'Content-Type': 'application/json'
            }
        });

        res.json({
            result: response.data
        });
    } catch (error) {
        res.status(500).json({
            error: error.message
        });
    }
});

app.listen(port, () => {
    console.log(`Server is running on http://localhost:${port}`);
});
